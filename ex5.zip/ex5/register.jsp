<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
String username = "";
String password = "";
String name = "";
String card = "";
String email = "";
String phone = "";
String error = "";

if("POST".equalsIgnoreCase(request.getMethod())) {
    username = request.getParameter("username");
    password = request.getParameter("password");
    name = request.getParameter("name");
    card = request.getParameter("card");
    email = request.getParameter("email");
    phone = request.getParameter("phone");

    if(username == null || !username.matches("[a-zA-Z0-9]{4,20}")) {
        error = "Username must contain 4-20 letters or numbers.";
    }
    else if(password == null || !password.matches(".{6,}")) {
        error = "Password must contain at least 6 characters.";
    }
    else if(name == null || !name.matches("[a-zA-Z ]{3,30}")) {
        error = "Enter a valid name.";
    }
    else if(card == null || !card.matches("\\d{16}")) {
        error = "Credit Card Number must contain 16 digits.";
    }
    else if(email == null || !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
        error = "Enter a valid email address.";
    }
    else if(phone == null || !phone.matches("\\d{10}")) {
        error = "Phone Number must contain 10 digits.";
    }
    else {
        session.setAttribute("username", username);
        session.setAttribute("password", password);
        session.setAttribute("name", name);
        session.setAttribute("card", card);
        session.setAttribute("email", email);
        session.setAttribute("phone", phone);

        response.sendRedirect("details.jsp");
        return;
    }
}
if(username == null) username = "";
if(password == null) password = "";
if(name == null) name = "";
if(card == null) card = "";
if(email == null) email = "";
if(phone == null) phone = "";
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User Registration</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eeeeee;
}

.container {
    width: 450px;
    margin: 40px auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #aaa;
}

h2 {
    text-align: center;
    background: #333;
    color: white;
    padding: 15px;
    margin: -25px -25px 25px -25px;
}

label {
    display: block;
    margin-top: 15px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 10px;
    margin-top: 7px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 11px;
    margin-top: 20px;
    background: #333;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.error {
    color: red;
    text-align: center;
    font-weight: bold;
    margin-bottom: 15px;
}
</style>
</head>

<body>

<div class="container">

<h2>♙ User Registration Form</h2>

<% if(!error.equals("")) { %>
<div class="error"><%= error %></div>
<% } %>

<form method="post" action="register.jsp">

<label>User Name</label>
<input type="text" name="username" value="<%= username %>" required>

<label>Password</label>
<input type="password" name="password" value="<%= password %>" required>

<label>Name</label>
<input type="text" name="name" value="<%= name %>" required>

<label>Credit Card Number</label>
<input type="text" name="card" value="<%= card %>" maxlength="16" required>

<label>Email</label>
<input type="text" name="email" value="<%= email %>" required>

<label>Phone Number</label>
<input type="text" name="phone" value="<%= phone %>" maxlength="10" required>

<button type="submit">Submit</button>

</form>

</div>

</body>
</html>