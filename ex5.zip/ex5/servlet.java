package servlet;



import java.io.IOException;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;



@WebServlet("/ExamServlet")

public class ExamServlet extends HttpServlet {



    protected void doPost(HttpServletRequest request,

            HttpServletResponse response)

            throws ServletException, IOException {



        String q1 = request.getParameter("q1");

        String q2 = request.getParameter("q2");

        String q3 = request.getParameter("q3");

        String q4 = request.getParameter("q4");

        String q5 = request.getParameter("q5");

        String q6 = request.getParameter("q6");



        int score = 0;



        // Q1

        if ("a".equals(q1)) {

            score++;

            request.setAttribute("s1", "correct");

            request.setAttribute("r1", "✓ Correct");

        } else {

            request.setAttribute("s1", "wrong");

            request.setAttribute("r1", "✗ Wrong");

        }



        // Q2

        if ("b".equals(q2)) {

            score++;

            request.setAttribute("s2", "correct");

            request.setAttribute("r2", "✓ Correct");

        } else {

            request.setAttribute("s2", "wrong");

            request.setAttribute("r2", "✗ Wrong");

        }



        // Q3

        if ("b".equals(q3)) {

            score++;

            request.setAttribute("s3", "correct");

            request.setAttribute("r3", "✓ Correct");

        } else {

            request.setAttribute("s3", "wrong");

            request.setAttribute("r3", "✗ Wrong");

        }



        // Q4

        if ("a".equals(q4)) {

            score++;

            request.setAttribute("s4", "correct");

            request.setAttribute("r4", "✓ Correct");

        } else {

            request.setAttribute("s4", "wrong");

            request.setAttribute("r4", "✗ Wrong");

        }



        // Q5

        if (q5 != null &&

            q5.trim().equalsIgnoreCase("javascript")) {



            score++;

            request.setAttribute("s5", "correct");

            request.setAttribute("r5", "✓ Correct");



        } else {

            request.setAttribute("s5", "wrong");

            request.setAttribute("r5", "✗ Wrong");

        }



        // Q6

        if (q6 != null &&

            q6.trim().equalsIgnoreCase("<a>")) {



            score++;

            request.setAttribute("s6", "correct");

            request.setAttribute("r6", "✓ Correct");



        } else {

            request.setAttribute("s6", "wrong");

            request.setAttribute("r6", "✗ Wrong");

        }



        // Convert MCQ answers into readable answers



        request.setAttribute("a1", getAnswer1(q1));

        request.setAttribute("a2", getAnswer2(q2));

        request.setAttribute("a3", getAnswer3(q3));

        request.setAttribute("a4", getAnswer4(q4));



        request.setAttribute("a5", q5);

        request.setAttribute("a6", q6);



        request.setAttribute("score", score);



        // Send result to result.jsp

        request.getRequestDispatcher("result.jsp")

                .forward(request, response);

    }



    private String getAnswer1(String q) {



        if ("a".equals(q))

            return "Hyper Text Markup Language";

        if ("b".equals(q))

            return "Home Tool Markup Language";

        if ("c".equals(q))

            return "Hyperlinks Text Markup Language";

        if ("d".equals(q))

            return "Hyper Text Machine Language";



        return "Not Answered";

    }



    private String getAnswer2(String q) {



        if ("a".equals(q))

            return "Pointers";

        if ("b".equals(q))

            return "Inheritance";

        if ("c".equals(q))

            return "Preprocessor";

        if ("d".equals(q))

            return "Header Files";



        return "Not Answered";

    }



    private String getAnswer3(String q) {



        if ("a".equals(q))

            return "HTML";

        if ("b".equals(q))

            return "CSS";

        if ("c".equals(q))

            return "Java";

        if ("d".equals(q))

            return "SQL";



        return "Not Answered";

    }



    private String getAnswer4(String q) {



        if ("a".equals(q))

            return "SQL";

        if ("b".equals(q))

            return "HTML";

        if ("c".equals(q))

            return "CSS";

        if ("d".equals(q))

            return "XML";



        return "Not Answered";

    }

}