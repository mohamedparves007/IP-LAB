<?php
session_start();

// Handle reset action if sent via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset') {
    session_unset();
    session_destroy();
    header("Location: register.php");
    exit();
}

$username = $_SESSION['username'] ?? null;
$password = $_SESSION['password'] ?? null;
$name     = $_SESSION['name'] ?? null;
$card     = $_SESSION['card'] ?? null;
$email    = $_SESSION['email'] ?? null;
$phone    = $_SESSION['phone'] ?? null;

if ($username === null) {
    header("Location: register.php");
    exit();
}

$maskedCard = ($card !== null && strlen($card) === 16) 
    ? "**** **** **** " . substr($card, 12, 4) 
    : $card;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registration Details</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eeeeee;
}

.container {
    width: 450px;
    margin: 40px auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #aaa;
}

h2 {
    text-align: center;
    background: #333;
    color: white;
    padding: 15px;
    margin: -25px -25px 25px -25px;
}

.detail-row {
    margin-bottom: 15px;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.detail-row label {
    display: block;
    font-weight: bold;
    color: #555;
    font-size: 14px;
}

.detail-row span {
    font-size: 16px;
    color: #222;
}

.btn-group {
    display: flex;
    gap: 10px;
    margin-top: 20px;
}

a.button, button {
    flex: 1;
    display: block;
    text-align: center;
    padding: 11px;
    background: #333;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

a.button:hover, button:hover {
    background: #555;
}
</style>
</head>

<body>

<div class="container">

<h2>♙ Registered Details</h2>

<div class="detail-row">
    <label>User Name</label>
    <span><?php echo htmlspecialchars($username); ?></span>
</div>

<div class="detail-row">
    <label>Password</label>
    <span>•••••• (Hidden)</span>
</div>

<div class="detail-row">
    <label>Name</label>
    <span><?php echo htmlspecialchars($name); ?></span>
</div>

<div class="detail-row">
    <label>Credit Card Number</label>
    <span><?php echo htmlspecialchars($maskedCard); ?></span>
</div>

<div class="detail-row">
    <label>Email</label>
    <span><?php echo htmlspecialchars($email); ?></span>
</div>

<div class="detail-row">
    <label>Phone Number</label>
    <span><?php echo htmlspecialchars($phone); ?></span>
</div>

<div class="btn-group">
    <a href="register.php" class="button">Back</a>
    <form action="details.php" method="post" style="flex: 1; margin: 0;">
        <input type="hidden" name="action" value="reset">
        <button type="submit">Start Over</button>
    </form>
</div>

</div>

</body>
</html>