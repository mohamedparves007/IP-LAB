<!DOCTYPE html>

<html>

<head>

    <title>Exam Result</title>



    <style>

        body {

            font-family: Arial;

            margin: 30px;

        }



        .box {

            width: 800px;

            margin: auto;

            border: 1px solid #000;

            padding: 20px;

        }



        h2 {

            text-align: center;

        }



        .score {

            text-align: center;

            border: 1px solid #000;

            padding: 12px;

            margin: 15px 0;

            font-size: 20px;

            font-weight: bold;

        }



        table {

            width: 100%;

            border-collapse: collapse;

        }



        th, td {

            border: 1px solid #999;

            padding: 8px;

            text-align: left;

        }



        th {

            background-color: #ddd;

        }



        .correct {

            background-color: #e5f7e5;

            color: green;

            font-weight: bold;

        }



        .wrong {

            background-color: #fbe5e5;

            color: red;

            font-weight: bold;

        }

    </style>

</head>



<body>



<div class="box">



<h2>Online Examination System</h2>



<h2>Result Summary</h2>



<div class="score">

    You scored <%= request.getAttribute("score") %> out of 6

</div>



<table>



<tr>

    <th>Q#</th>

    <th>Question</th>

    <th>Your Answer</th>

    <th>Correct Answer</th>

    <th>Status</th>

</tr>



<tr class="<%= request.getAttribute("s1") %>">

    <td>1</td>

    <td>What does HTML stand for?</td>

    <td><%= request.getAttribute("a1") %></td>

    <td>Hyper Text Markup Language</td>

    <td><%= request.getAttribute("r1") %></td>

</tr>



<tr class="<%= request.getAttribute("s2") %>">

    <td>2</td>

    <td>Which is a Java feature?</td>

    <td><%= request.getAttribute("a2") %></td>

    <td>Inheritance</td>

    <td><%= request.getAttribute("r2") %></td>

</tr>



<tr class="<%= request.getAttribute("s3") %>">

    <td>3</td>

    <td>Which language is used to style web pages?</td>

    <td><%= request.getAttribute("a3") %></td>

    <td>CSS</td>

    <td><%= request.getAttribute("r3") %></td>

</tr>



<tr class="<%= request.getAttribute("s4") %>">

    <td>4</td>

    <td>Which is used to store data in a database?</td>

    <td><%= request.getAttribute("a4") %></td>

    <td>SQL</td>

    <td><%= request.getAttribute("r4") %></td>

</tr>



<tr class="<%= request.getAttribute("s5") %>">

    <td>5</td>

    <td>Which language makes web pages interactive?</td>

    <td><%= request.getAttribute("a5") %></td>

    <td>JavaScript</td>

    <td><%= request.getAttribute("r5") %></td>

</tr>



<tr class="<%= request.getAttribute("s6") %>">

    <td>6</td>

    <td>Which tag is used to create a hyperlink in HTML?</td>

    <td><%= request.getAttribute("a6") %></td>

    <td>&lt;a&gt;</td>

    <td><%= request.getAttribute("r6") %></td>

</tr>



</table>



<br>



<center>

<i>Review the questions marked "Wrong" above and note the correct answer for each.</i>

</center>



</div>



</body>

</html>

