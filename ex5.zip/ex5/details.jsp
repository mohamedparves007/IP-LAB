<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String username = (String) session.getAttribute("username");
    String password = (String) session.getAttribute("password");
    String name = (String) session.getAttribute("name");
    String card = (String) session.getAttribute("card");
    String email = (String) session.getAttribute("email");
    String phone = (String) session.getAttribute("phone");

    // Mask card for security display (optional, showing last 4 digits)
    String maskedCard = (card != null && card.length() == 16) 
        ? "**** **** **** " + card.substring(12) 
        : card;

    if (username == null) {
        response.sendRedirect("register.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registration Details</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eeeeee;
}

.container {
    width: 450px;
    margin: 40px auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #aaa;
}

h2 {
    text-align: center;
    background: #333;
    color: white;
    padding: 15px;
    margin: -25px -25px 25px -25px;
}

.detail-row {
    margin-bottom: 15px;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.detail-row label {
    display: block;
    font-weight: bold;
    color: #555;
    font-size: 14px;
}

.detail-row span {
    font-size: 16px;
    color: #222;
}

.btn-group {
    display: flex;
    gap: 10px;
    margin-top: 20px;
}

a.button, button {
    flex: 1;
    display: block;
    text-align: center;
    padding: 11px;
    background: #333;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

a.button:hover, button:hover {
    background: #555;
}
</style>
</head>

<body>

<div class="container">

<h2>♙ Registered Details</h2>

<div class="detail-row">
    <label>User Name</label>
    <span><%= username %></span>
</div>

<div class="detail-row">
    <label>Password</label>
    <span>•••••• (Hidden)</span>
</div>

<div class="detail-row">
    <label>Name</label>
    <span><%= name %></span>
</div>

<div class="detail-row">
    <label>Credit Card Number</label>
    <span><%= maskedCard %></span>
</div>

<div class="detail-row">
    <label>Email</label>
    <span><%= email %></span>
</div>

<div class="detail-row">
    <label>Phone Number</label>
    <span><%= phone %></span>
</div>

<div class="btn-group">
    <a href="register.jsp" class="button">Back</a>
    <form action="register.jsp" method="get" style="flex: 1; margin: 0;">
        <button type="submit" onclick="<% session.invalidate(); %>">Start Over</button>
    </form>
</div>

</div>

</body>
</html>