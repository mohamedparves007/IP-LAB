<%@ page language="java" contentType="text/html; charset=UTF-8" %>

<%
String username = "";
String password = "";
String name = "";
String card = "";
String email = "";
String phone = "";
String error = "";

if(request.getMethod().equals("POST")) {

    username = request.getParameter("username");
    password = request.getParameter("password");
    name = request.getParameter("name");
    card = request.getParameter("card");
    email = request.getParameter("email");
    phone = request.getParameter("phone");

    if(username == null || !username.matches("[a-zA-Z0-9]{4,20}")) {
        error = "Username must contain 4-20 letters or numbers.";
    }
    else if(password == null || !password.matches(".{6,}")) {
        error = "Password must contain at least 6 characters.";
    }
    else if(name == null || !name.matches("[a-zA-Z ]{3,30}")) {
        error = "Enter a valid name.";
    }
    else if(card == null || !card.matches("\\d{16}")) {
        error = "Credit Card Number must contain 16 digits.";
    }
    else if(email == null || !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
        error = "Enter a valid email address.";
    }
    else if(phone == null || !phone.matches("\\d{10}")) {
        error = "Phone Number must contain 10 digits.";
    }
    else {
        session.setAttribute("username", username);
        session.setAttribute("password", password);
        session.setAttribute("name", name);
        session.setAttribute("card", card);
        session.setAttribute("email", email);
        session.setAttribute("phone", phone);

        response.sendRedirect("details.jsp");
        return;
    }
}
%>