<?php
session_start();
$username = "";
$password = "";
$name = "";
$card = "";
$email = "";
$phone = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $name     = $_POST['name'] ?? '';
    $card     = $_POST['card'] ?? '';
    $email    = $_POST['email'] ?? '';
    $phone    = $_POST['phone'] ?? '';

    if ($username === '' || !preg_match('/^[a-zA-Z0-9]{4,20}$/', $username)) {
        $error = "Username must contain 4-20 letters or numbers.";
    } elseif ($password === '' || !preg_match('/^.{6,}$/', $password)) {
        $error = "Password must contain at least 6 characters.";
    } elseif ($name === '' || !preg_match('/^[a-zA-Z ]{3,30}$/', $name)) {
        $error = "Enter a valid name.";
    } elseif ($card === '' || !preg_match('/^\d{16}$/', $card)) {
        $error = "Credit Card Number must contain 16 digits.";
    } elseif ($email === '' || !preg_match('/^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$/', $email)) {
        $error = "Enter a valid email address.";
    } elseif ($phone === '' || !preg_match('/^\d{10}$/', $phone)) {
        $error = "Phone Number must contain 10 digits.";
    } else {
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        $_SESSION['name']     = $name;
        $_SESSION['card']     = $card;
        $_SESSION['email']    = $email;
        $_SESSION['phone']    = $phone;

        header("Location: details.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User Registration</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eeeeee;
}

.container {
    width: 450px;
    margin: 40px auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #aaa;
}

h2 {
    text-align: center;
    background: #333;
    color: white;
    padding: 15px;
    margin: -25px -25px 25px -25px;
}

label {
    display: block;
    margin-top: 15px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 10px;
    margin-top: 7px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 11px;
    margin-top: 20px;
    background: #333;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.error {
    color: red;
    text-align: center;
    font-weight: bold;
    margin-bottom: 15px;
}
</style>
</head>

<body>

<div class="container">

<h2>♙ User Registration Form</h2>

<?php if($error !== ""): ?>
<div class="error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<form method="post" action="register.php">

<label>User Name</label>
<input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" required>

<label>Password</label>
<input type="password" name="password" value="<?php echo htmlspecialchars($password); ?>" required>

<label>Name</label>
<input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required>

<label>Credit Card Number</label>
<input type="text" name="card" value="<?php echo htmlspecialchars($card); ?>" maxlength="16" required>

<label>Email</label>
<input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>" required>

<label>Phone Number</label>
<input type="text" name="phone" value="<?php echo htmlspecialchars($phone); ?>" maxlength="10" required>

<button type="submit">Submit</button>

</form>

</div>

</body>
</html>