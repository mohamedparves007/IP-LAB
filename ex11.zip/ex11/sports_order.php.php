<?php
$conn = new mysqli("localhost", "root", "mysql", "sports_store");
if ($conn->connect_error) {
 die("Database connection failed");
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $name = $_POST["name"];
 $email = $_POST["email"];
 $category = $_POST["category"];
 $unit_size = $_POST["unit_size"];
 $unit_price = $_POST["unit_price"];
 $stmt = $conn->prepare(
 "INSERT INTO orders
 (name, email, category, unit_size, unit_price)
 VALUES (?, ?, ?, ?, ?)"
 );
 $stmt->bind_param(
 "sssid",
 $name,
 $email,
 $category,
 $unit_size,
 $unit_price
 );
 if ($stmt->execute()) {
 header("Location: sports_details.php");
 exit();
 }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Sports Items Order</title>
<style>
* {
 box-sizing: border-box;
}
body {
 font-family: Arial, sans-serif;
 margin: 0;
 padding: 40px;
 background: white;
}
.container {
 display: flex;
 gap: 30px;
 width: 100%;
 max-width: 1100px;
 margin: auto;
}
.box {
 width: 50%;
}
h2 {
 background: #333;
 color: white;
 text-align: center;
 padding: 18px;
 margin: 0 0 30px 0;
 font-size: 22px;
}
label {
 display: block;
 margin-top: 22px;
 margin-bottom: 8px;
 font-size: 15px;
 font-weight: bold;
}
input,
select {
 width: 100%;
height: 42px;
 padding: 8px;
 font-size: 14px;
 border: none;
 border-bottom: 1px solid #ccc;
 outline: none;
}
button {
 width: 100%;
 height: 52px;
 margin-top: 35px;
 background: #333;
 color: white;
 border: none;
 font-size: 16px;
 cursor: pointer;
}
button:hover {
 background: #444;
}
</style>
</head>
<body>
<div class="container">
 <div class="box">
 <h2>Sports Items Order</h2>
 <form method="post">
 <label>Name</label>
 <input type="text" name="name" required>
 <label>Email</label>
 <input type="email" name="email" required>
 <label>Category</label>
 <select name="category" required>
 <option value="Sports">Sports</option>
 </select>
 <label>Unit Size (Number of Units)</label>
 <input type="number" name="unit_size" min="1" required>
 <label>Unit Price (per Unit)</label>
 <input type="number" name="unit_price" min="1" required>
 <button type="submit">Place Order</button>
 </form>
 </div>
 <div class="box">
 <h2>Sports Items Order Details</h2>
 </div>
</div>
</body>
</html>
