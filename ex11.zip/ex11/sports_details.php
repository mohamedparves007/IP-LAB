<?php
$conn = new mysqli("localhost", "root", "", "sports_store");
if ($conn->connect_error) {
 die("Database connection failed");
}
$result = $conn->query(
 "SELECT * FROM orders ORDER BY id DESC"
);
?>
<!DOCTYPE html>
<html>
<head>
<title>Sports Items Order Details</title>
<style>
* {
 box-sizing: border-box;
}
body {
 font-family: Arial, sans-serif;
 margin: 0;
 padding: 40px;
 background: white;
}
.container {
width: 100%;
 max-width: 1100px;
 margin: auto;
}
h2 {
 background: #333;
 color: white;
 text-align: center;
 padding: 18px;
 margin: 0 0 30px 0;
 font-size: 22px;
}
table {
 width: 100%;
 border-collapse: collapse;
}
th {
 background: #333;
 color: white;
 padding: 14px 8px;
 font-size: 14px;
}
td {
 padding: 18px 8px;
 text-align: center;
 border-bottom: 1px solid #ddd;
 font-size: 14px;
}
.button {
 display: block;
 width: 165px;
 margin: 30px auto;
 padding: 15px;
 background: #333;
 color: white;
 text-align: center;
 text-decoration: none;
 font-size: 14px;
}
</style>
</head>
<body>
<div class="container">
 <h2>Sports Items Order Details</h2>
 <table>
 <tr>
 <th>Name</th>
 <th>Email</th>
 <th>Category</th>
 <th>Unit Size<br>(Number of Units)</th>
 <th>Unit Price<br>(per Unit)</th>
 </tr>
 <?php while ($row = $result->fetch_assoc()) { ?>
 <tr>
 <td>
 <?php echo htmlspecialchars($row["name"]); ?>
 </td>
 <td>
 <?php echo htmlspecialchars($row["email"]); ?>
 </td>
 <td>
 <?php echo htmlspecialchars($row["category"]); ?>
 </td>
 <td>
 <?php echo $row["unit_size"]; ?>
 </td>
 <td>
 ₹<?php echo number_format($row["unit_price"], 2); ?>
 </td>
 </tr>
 <?php } ?>
 </table>
 <a href="sports_order.php" class="button">
 Place Another Order
</a>
</div>
</body>
</html>