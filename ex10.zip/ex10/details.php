<?php
session_start(); 

if (!isset($_SESSION["username"])) { 
    header("Location: registration.php"); 
    exit(); 
} 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registration Details</title>
    <style>
        * {
            box-sizing: border-box; 
        } 
        body {
            margin: 0;
            padding: 40px; 
            font-family: Arial, sans-serif; 
            background: #eeeeee; 
        } 
        .main {
            width: 100%;
            max-width: 1050px;
            margin: auto; 
        } 
        .box {
            width: 50%;
            margin: auto; 
            background: #eeeeee; 
            border: 1px solid #d0d0d0; 
            border-radius: 3px;
            overflow: hidden; 
        } 
        .header {
            background: #333333; 
            color: white; 
            text-align: center; 
            padding: 15px; 
            font-size: 21px;
            font-weight: bold; 
        } 
        .details-box {
            background: #f7f7f7; 
            margin: 20px; 
            padding: 18px;
            border-radius: 8px; 
            box-shadow: 0 1px 5px #cccccc; 
        } 
        .title {
            background: #eeeeee; 
            text-align: center; 
            padding: 14px; 
            font-size: 18px; 
            font-weight: bold;
            margin-bottom: 15px; 
        } 
        .row {
            display: flex;
            margin-bottom: 5px; 
        } 
        .label {
            width: 42%;
            background: #eeeeee; 
            padding: 12px; 
            font-weight: bold;
            font-size: 13px; 
        } 
        .value {
            width: 58%; 
            background: #f1f1f1; 
            padding: 12px;
            font-size: 13px; 
        } 
        .button {
            display: block;
            width: 150px; 
            margin: 30px auto 5px; 
            padding: 10px; 
            background: #333333; 
            color: white; 
            text-align: center; 
            text-decoration: none; 
            border-radius: 5px;
            font-size: 13px; 
        } 
    </style>
</head>
<body>
    <div class="main">
        <div class="box">
            <div class="header">♙ &nbsp; Registration Details</div>
            <div class="details-box">
                <div class="title">User Registration Details</div>
                
                <div class="row">
                    <div class="label">UserName</div>
                    <div class="value"><?php echo htmlspecialchars($_SESSION["username"]); ?></div>
                </div>
                
                <div class="row">
                    <div class="label">Password</div>
                    <div class="value"><?php echo str_repeat("•", strlen($_SESSION["password"])); ?></div>
                </div>
                
                <div class="row">
                    <div class="label">Name</div>
                    <div class="value"><?php echo htmlspecialchars($_SESSION["name"]); ?></div>
                </div>
                
                <div class="row">
                    <div class="label">Credit Card Number</div>
                    <div class="value"><?php echo htmlspecialchars($_SESSION["card"]); ?></div>
                </div>
                
                <div class="row">
                    <div class="label">Email</div>
                    <div class="value"><?php echo htmlspecialchars($_SESSION["email"]); ?></div>
                </div>
                
                <div class="row">
                    <div class="label">PhoneNumber</div>
                    <div class="value"><?php echo htmlspecialchars($_SESSION["phone"]); ?></div>
                </div>
                
                <a href="registration.php" class="button">Back</a>
            </div>
        </div>
    </div>
</body>
</html>