<?php
session_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION["username"] = $_POST["username"]; 
    $_SESSION["password"] = $_POST["password"]; 
    $_SESSION["name"] = $_POST["name"]; 
    $_SESSION["card"] = $_POST["card"]; 
    $_SESSION["email"] = $_POST["email"]; 
    $_SESSION["phone"] = $_POST["phone"];
    
    header("Location: details.php"); 
    exit(); 
} 
?>
<!DOCTYPE html>
<html>
<head>
    <title>UserRegistrationForm</title>
    <style>
        * {
            box-sizing: border-box; 
        } 
        body {
            margin: 0;
            padding: 40px; 
            font-family: Arial, sans-serif; 
            background: #eeeeee; 
        } 
        .main {
            width: 100%;
            max-width: 1050px;
            margin: auto;
            display: flex;
            gap: 15px; 
        } 
        .box {
            width: 50%;
            background: #eeeeee; 
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            overflow: hidden; 
        } 
        .header {
            background: #333333;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 21px;
            font-weight: bold; 
        } 
        .form-box {
            background: #f7f7f7;
            margin: 20px;
            padding: 25px;
            border-radius: 8px; 
            box-shadow: 0 1px 5px #cccccc; 
        } 
        label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 7px;
            margin-top: 14px; 
        } 
        input {
            width: 100%;
            height: 34px;
            padding: 7px 10px; 
            border: 1px solid #cccccc;
            border-radius: 5px;
            font-size: 13px;
            background: white; 
        } 
        button {
            width: 100%;
            height: 35px;
            margin-top: 18px;
            border: none;
            border-radius: 5px;
            background: #333333;
            color: white;
            font-size: 14px; 
        } 
    </style>
</head>
<body>
    <div class="main">
        <div class="box">
            <div class="header">♙ &nbsp; User Registration Form</div>
            <div class="form-box">
                <form method="post">
                    <label>UserName</label>
                    <input type="text" name="username" required>
                    <label>Password</label>
                    <input type="password" name="password" required>
                    <label>Name</label>
                    <input type="text" name="name" required>
                    <label>Credit Card Number</label>
                    <input type="text" name="card" required>
                    <label>Email</label>
                    <input type="email" name="email" required>
                    <label>PhoneNumber</label>
                    <input type="text" name="phone" required>
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>
        <div class="box">
            <div class="header">♙ &nbsp; Registration Details</div>
        </div>
    </div>
</body>
</html>