<?php 
$library = simplexml_load_file("books.xml") 
    or die("Unable to load books.xml"); 

echo "<table border='1' cellpadding='8' cellspacing='0'>"; 
echo "<tr>"; 
echo "<th>Book Title</th>";
echo "<th>Author Name</th>";
echo "<th>Published Year</th>";
echo "<th>Book Price</th>";
echo "</tr>"; 

foreach ($library->book as $book) { 
    echo "<tr>"; 
    echo "<td>" . $book->title . "</td>"; 
    echo "<td>" . $book->author . "</td>"; 
    echo "<td>" . $book->year . "</td>"; 
    echo "<td>$" . $book->price . "</td>"; 
    echo "</tr>"; 
}

echo "</table>"; 
?>